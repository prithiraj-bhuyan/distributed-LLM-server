# Base Class (basic blueprint)
class Vehicle:
    def __init__(self, name, speed):
        self.name = name
        self.speed = speed  # in mph

    def move(self):
        print(f"{self.name} moves at {self.speed} mph.")

# Task 1: Inherit the base class to create 2 different vehicle classes



# Composition Example
# Task 2: Create classes of features you want to use inside of a Car 
# (Note: We wont be inheriting them since Radio is not a Vehicle, it is just a feature inside a vehicle)



# Task 3: Compose (fit-in) the features into a Vehicle



# Use the stuff we created
if __name__ == "__main__":
    tank = Tank("M1 Abrams", 45, "120mm armor")
    humvee = Humvee("Humvee", 60, 4)
    armored_car = ArmoredCar("LAV-25", 55, Weapon("25mm autocannon"), Radio(50))

    tank.move()
    tank.fire()

    humvee.move()
    humvee.transport_troops()

    armored_car.move()
    armored_car.attack()
    armored_car.call_support()